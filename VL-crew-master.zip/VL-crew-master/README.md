# Introduction (Round 0)

| Discipline  | Engineering |
| ------------- | ------------- |
| Lab.  | Data Structure  |
| Experiment  | Operations on Queue ADT  |

**ABOUT THE EXPERIMENT**
To demonstrate the mechanism of Insertion and Deletion Operations in Queue using Linked-List 

| Name of Developer | Amit Tripathi |
|-----------|----------|
| Institute | Rajkiya Engineering College,Banda |
| Email id | amittri13@gmail.com |
| Department | Applied Science & Humanities |

Contributors List



| SrNo | Name | Faculty or Student | Department | Institute |Email id|
|----- |-------------|--------------------|-----------|------------|---------|
|1 | Amit Tripathi | Faculty | Applied Science & Humanities | Rajkiya Engineering College,Banda | amittri13@gmail.com|
|2 | Anubhav Rawat | Student| Information Technology| Rajkiya Engineering College,Banda| anubhavrawat62@gmail.com|
|3 | Vinayaka Dwivedi | Student | Information Technology|Rajkiya Engineering College,Banda| dwivedivinayaka99@gmail.com|
|4 | Avinyash Singh | Student | Electrical Engineering | Rajkiya Engineering College,Banda| avinyash17@gmail.com|
|5 | Nayan Gupta | Student | Information Technology | Rajkiya Engineering College,Banda| nayan448@gmail.com|

