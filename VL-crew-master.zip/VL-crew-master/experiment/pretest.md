Pre Question :

1.  What is datatype of a queue?
a) Abstract       
b) Integer        
c) Float        
d) Double
2. The essential condition that is checked before insertion in a queue is?
a) Underflow    
b) Overflow     
c) Front value  
d) Rear value  
3. The essential condition that is checked before deletion from a queue is?
a) Underflow    
b) Overflow      
c) Rear value    
d) Front value

