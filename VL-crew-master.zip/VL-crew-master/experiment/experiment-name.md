Operation on queue ADT using Linked-List
