Post Question :

1. In linked list implementation of a queue, where is the new element inserted?
a) At head of link list
b) At center of link list
c) At tail of the link list
d) None of these

2. In linked list implementation of a queue, from where is the item deleted?
a) At head of link list
b) At center of link list
c) At tail of the link list
d) None of these
