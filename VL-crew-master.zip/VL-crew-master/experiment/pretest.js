function fuc1(e)
	{
		document.getElementById("ms1").innerHTML="Your answer is correct";
				document.getElementById("ms2").innerHTML="";
						document.getElementById("ms3").innerHTML="";
						alert("Your answer is correct");
					}
function fuc2(e)
	{
		document.getElementById("ms1").innerHTML="";
				document.getElementById("ms2").innerHTML="Your answer is wrong!!";
						document.getElementById("ms3").innerHTML="Correct Answer: Underflow ";
					}
function fuc3(e)
	{
		document.getElementById("mt1").innerHTML="Your answer is correct";
				document.getElementById("mt2").innerHTML="";
						document.getElementById("mt3").innerHTML="";
					}
function fuc4(e)
	{
		document.getElementById("mt1").innerHTML="";
				document.getElementById("mt2").innerHTML="Your answer is wrong!!";
						document.getElementById("mt3").innerHTML="Correct Answer: Overflow ";
					}
function fuc5(e)
	{
		document.getElementById("mp1").innerHTML="Your answer is correct";
				document.getElementById("mp2").innerHTML="";
						document.getElementById("mp3").innerHTML="";
					}
function fuc6(e)
	{
		document.getElementById("mp1").innerHTML="";
				document.getElementById("mp2").innerHTML="Your answer is wrong!!";
						document.getElementById("mp3").innerHTML="Correct Answer: Abstract";
					}
