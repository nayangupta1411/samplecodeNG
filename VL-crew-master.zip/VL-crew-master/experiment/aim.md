Aim:

To demonstrate the mechanism of Insertion and Deletion in Queue ADT using Linked-List
