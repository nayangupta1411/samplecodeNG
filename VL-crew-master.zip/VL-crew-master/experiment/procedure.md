Procedure :

1) Enter elements in the queue 
2) Press the ‘Enter’ button
3) Click the ‘Insertion’ button
4) Click the ‘Deletion’ button 
